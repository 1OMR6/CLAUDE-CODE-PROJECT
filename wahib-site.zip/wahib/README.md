# WAHIB — موقع وهيب (حلب)
1. `npm install && npm run dev` للتجربة محليًا.
2. النشر: `npx vercel` (أو ارفع المجلد على vercel.com).
3. في Vercel > Settings > Environment Variables أضف:
   - `RESEND_API_KEY` (مفتاح مجاني من resend.com — سجّل بنفس بريد WAHIBARCHITECTS@GMAIL.COM)
   - اختياري: `MAIL_TO`, `MAIL_FROM` (بعد توثيق نطاقك)
4. عدّل `site` في `lib/config.js` إلى رابطك النهائي.
