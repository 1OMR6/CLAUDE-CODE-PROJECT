"use client";
import { useState } from "react";
export default function QuoteForm() {
  const [st, setSt] = useState("idle");
  async function submit(e) {
    e.preventDefault(); setSt("sending");
    const d = Object.fromEntries(new FormData(e.target));
    try { const r = await fetch("/api/quote",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(d)});
      if(!r.ok) throw 0; setSt("ok"); e.target.reset(); } catch { setSt("err"); }
  }
  return (<form onSubmit={submit}>
    <input name="website" tabIndex={-1} autoComplete="off" style={{display:"none"}}/>
    <input name="name" placeholder="الاسم" required autoComplete="name"/>
    <input name="phone" type="tel" placeholder="رقم الهاتف" required autoComplete="tel" dir="ltr" style={{textAlign:"right"}}/>
    <textarea name="need" rows={4} placeholder="ماذا تحتاج؟" required/>
    <button className="b" disabled={st==="sending"}>{st==="sending"?"جارٍ الإرسال…":"أرسل الطلب"}</button>
    {st==="ok"&&<p>تم الإرسال، سنتواصل معك قريبًا.</p>}
    {st==="err"&&<p>تعذّر الإرسال. يرجى الاتصال بنا مباشرة.</p>}
  </form>);
}
