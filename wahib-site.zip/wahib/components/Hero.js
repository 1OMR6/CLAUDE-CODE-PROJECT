"use client";
import { useEffect, useRef } from "react";
import { config as c } from "../lib/config";
// نقاط ظهور النصوص الثلاثة (نسبة التمرير)
const RANGES = [[0.0,0.28],[0.36,0.64],[0.72,1.01]];
export default function Hero() {
  const wrap = useRef(null), cv = useRef(null), hls = useRef([]);
  useEffect(() => {
    const canvas = cv.current, ctx = canvas.getContext("2d", { alpha:false });
    const N = c.frameCount, imgs = new Array(N);
    let cur = 0, target = 0, last = -1, raf, dpr = Math.min(window.devicePixelRatio||1, 2);
    const draw = (i) => {
      const im = imgs[i] || imgs.slice(0,i+1).reverse().find(Boolean);
      if (!im) return;
      const W = canvas.width, H = canvas.height;
      const s = Math.max(W/im.naturalWidth, H/im.naturalHeight); // cover على الجوال
      const mobile = W/H < 0.8;
      const k = mobile ? s : Math.min(W/im.naturalWidth, H/im.naturalHeight); // contain على الحاسوب
      const w = im.naturalWidth*k, h = im.naturalHeight*k;
      ctx.clearRect(0,0,W,H); ctx.drawImage(im,(W-w)/2,(H-h)/2,w,h);
    };
    const resize = () => { canvas.width = innerWidth*dpr; canvas.height = innerHeight*dpr; last=-1; };
    const onScroll = () => {
      const r = wrap.current.getBoundingClientRect();
      const p = Math.min(1, Math.max(0, -r.top / (r.height - innerHeight)));
      target = p*(N-1); onScroll.p = p;
    };
    const load = (i) => { const im = new Image(); im.decoding="async"; im.src = `/frames/f${String(i+1).padStart(4,"0")}.jpg`; im.onload=()=>{imgs[i]=im; last=-1}; };
    // الإطار الأول فورًا، ثم الباقي بالتدريج
    load(0); let q=1; const pump=()=>{ for(let n=0;n<6&&q<N;n++) load(q++); if(q<N) setTimeout(pump,60); }; pump();
    const tick = () => {
      cur += (target-cur)*0.18; if (Math.abs(target-cur)<0.01) cur=target;
      const i = Math.round(cur);
      if (i!==last) { draw(i); last=i; }
      const p = onScroll.p||0;
      hls.current.forEach((el,k)=>{ if(!el) return; const [a,b]=RANGES[k], m=(b-a), t=(p-a)/m;
        const o = t<0||t>1 ? 0 : Math.min(1,t*6,(1-t)*6);
        el.style.opacity = o; el.style.transform = `translateY(${(1-o)*18}px)`; });
      raf = requestAnimationFrame(tick);
    };
    resize(); onScroll(); addEventListener("resize",resize); addEventListener("scroll",onScroll,{passive:true});
    raf = requestAnimationFrame(tick);
    return () => { cancelAnimationFrame(raf); removeEventListener("resize",resize); removeEventListener("scroll",onScroll); };
  }, []);
  return (
    <div className="hero" ref={wrap}><div className="stick">
      <div className="bg" aria-hidden="true"/><canvas ref={cv} aria-hidden="true"/><div className="shade"/>
      <div className="brand">WAHIB</div>
      <div className="hl" ref={e=>hls.current[0]=e}><h1>شقق للبيع في {c.city}، {c.country}</h1><p style={{fontSize:"1.1rem",fontWeight:500,marginTop:8}}>{c.headlines[0]}</p></div>
      <div className="hl" ref={e=>hls.current[1]=e}><h2>{c.headlines[1]}</h2></div>
      <div className="hl" ref={e=>hls.current[2]=e}><h2>{c.headlines[2]}</h2><p style={{marginTop:16}}><a className="b" href="#quote" style={{pointerEvents:"auto"}}>اطلب عرض سعر مجاني</a></p></div>
      <div className="hint">مرّر للأسفل ↓</div>
    </div></div>);
}
