import "./globals.css";
import { Cairo } from "next/font/google";
import { config as c } from "../lib/config";
const cairo = Cairo({ subsets:["arabic","latin"], variable:"--font", display:"swap" });
const title = `شقق للبيع في ${c.city}، ${c.country} | ${c.name} WAHIB`;
const description = `وحدات سكنية في ${c.city} تبدأ من ${c.priceFrom}. اطلب عرض سعر مجاني من ${c.name}.`;
export const metadata = { metadataBase:new URL(c.site), title, description, openGraph:{title,description,images:["/og.jpg"],locale:"ar_SY",type:"website"} };
export const viewport = { width:"device-width", initialScale:1, viewportFit:"cover", themeColor:"#0b1020" };
export default function RootLayout({ children }) {
  const ld = { "@context":"https://schema.org","@type":"RealEstateAgent",name:`${c.name} WAHIB`,telephone:c.phone,email:c.email.toLowerCase(),areaServed:{"@type":"City",name:c.city},address:{"@type":"PostalAddress",addressLocality:c.city,addressCountry:"SY"} };
  return (<html lang="ar" dir="rtl" className={cairo.variable}><body>
    <script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify(ld)}}/>
    {children}</body></html>);
}
