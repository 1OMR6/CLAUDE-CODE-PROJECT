import { config as c } from "../../../lib/config";
const esc = s => String(s).replace(/[&<>]/g, m=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[m]));
export async function POST(req) {
  const d = await req.json().catch(()=>({}));
  if (d.website) return Response.json({ok:true}); // honeypot
  const name=String(d.name||"").slice(0,100), phone=String(d.phone||"").slice(0,40), need=String(d.need||"").slice(0,2000);
  if (!name||!phone||!need) return Response.json({error:"missing"},{status:400});
  const key = process.env.RESEND_API_KEY;
  if (!key) return Response.json({error:"not configured"},{status:500});
  const r = await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${key}`,"Content-Type":"application/json"},
    body:JSON.stringify({from:process.env.MAIL_FROM||"WAHIB <onboarding@resend.dev>",to:[process.env.MAIL_TO||c.email.toLowerCase()],reply_to:undefined,
      subject:`طلب عرض سعر جديد: ${name}`,html:`<div dir="rtl"><p><b>الاسم:</b> ${esc(name)}</p><p><b>الهاتف:</b> ${esc(phone)}</p><p><b>الطلب:</b><br>${esc(need)}</p></div>`})});
  return r.ok ? Response.json({ok:true}) : Response.json({error:"send failed"},{status:502});
}
