import Hero from "../components/Hero";
import QuoteForm from "../components/QuoteForm";
import { config as c } from "../lib/config";
export default function Home() {
  return (<main>
    <Hero/>
    <section className="s"><h2 className="t">خدماتنا</h2>
      <div className="grid">{c.services.map(s=>(<div className="card" key={s.title}><h3>{s.title}</h3><p>{s.desc}</p><div className="price">تبدأ من {c.priceFrom}</div></div>))}</div></section>
    <section className="s" id="quote"><h2 className="t">اطلب عرض سعر مجاني</h2><QuoteForm/></section>
    <section className="s"><h2 className="t">منطقة الخدمة</h2><p>نخدم مدينة {c.city}، {c.country}.</p></section>
    <section className="s"><h2 className="t">أسئلة شائعة</h2>{c.faq.map(([q,a])=>(<details key={q}><summary>{q}</summary><p>{a}</p></details>))}</section>
    <footer><p>{c.name} · WAHIB — {c.city}، {c.country}</p><p dir="ltr"><a href={`tel:${c.phone}`}>{c.phone}</a> · <a href={`mailto:${c.email}`}>{c.email.toLowerCase()}</a></p></footer>
    <div className="sticky"><a className="b" href={`tel:${c.phone}`}>اتصل الآن</a><a className="b" href="#quote">عرض سعر مجاني</a></div>
  </main>);
}
